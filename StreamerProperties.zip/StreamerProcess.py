import os
import sys

from SPE_processing import SPE_processing
from DetectStreamers import *
#TODO: finish
def get_conductivity(folder):
	index = folder.find(folder, "m")
	conductiv = folder[:index]
	conductiv.replace("_",".")
	return float(conductiv)








path = "./data/"
filename = "database.csv"

#conductivities = get_conductivities()
print(next(os.walk("./partial_results")))


folders = next(os.walk(path))[1]
print(folders)

for folder in folders:
	files = next(os.walk(path + folder))[1]
	conductivities = get_conductivity(folder)
	spe_reader = SPE_processing(folder + sio) 

	for file in files:
		print("Processing file " + file)
		spe_reader.load_single_file(path + folder + files)

		for image in spe_reader.get_images():
			# If streamer is not on the image.
			result = process_image(image)
			if not result:
				continue

			

		spe_reader.delete_images()
	break
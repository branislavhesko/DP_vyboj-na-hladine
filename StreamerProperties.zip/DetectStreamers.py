"""Summary

Attributes:
    eroded (list): Description
"""
import numpy as np
import cv2
from matplotlib import pyplot
from ImageFunctions import *
import skimage.io
import skimage.morphology
from matplotlib import rc
from skimage.filters.rank import gradient
import os
import sys
from scipy.signal import medfilt
from scipy import ndimage as ndi
from scipy.ndimage.measurements import center_of_mass

# os.listdir("./")

from Exceptions import *

#TODO: add comments
def detect_streamers_watershed(image):
    """Summary
    
    Args:
        image (TYPE): Description
    
    Raises:
        IOError: Description
    """

    if type(image) != np.ndarray:
        raise IOError("One of the images is not ndarray type")

    _,seeds = cv2.threshold(image, 3*np.mean(image), 255, cv2.THRESH_BINARY)
    image_blurred = blur_and_threshold_image(image)
    distance_image = ndi.distance_transform_edt(image_blurred)
    label = skimage.morphology.label(seeds, neighbors=4)

    watershed_im = skimage.morphology.watershed(-distance_image, label, mask = image_blurred)
    print(watershed_im)
    watershed_im =  remove_small_objects(watershed_im)
    imshow(watershed_im)


def vertical_projection(image):
    """Summary
    
    Args:
        image (TYPE): Description
    
    Returns:
        TYPE: Description
    
    Raises:
        IOError: Description
    """
    if type(image) != np.ndarray:
        raise IOError("Image is not ndarray type")

    vertical_proj_array = np.zeros(image.shape[0])
    vertical_proj_array = np.mean(image, axis=1)
    return vertical_proj_array


#FIXME: mean value?
def detect_ROI(image):
    """
    docstring here
            :param image:
    
    Args:
        image (TYPE): Description
    
    Returns:
        TYPE: Description
    """
    vertical_proj_array = medfilt(vertical_projection(image), 15)
    mean_value = np.mean(vertical_proj_array)
    poz_max = np.argmax(vertical_proj_array)
    value = vertical_proj_array[poz_max]
    i = 0

    while value > mean_value:
        i += 1
        value = vertical_proj_array[poz_max - i]

    lower_limit = poz_max - i

    i = 0
    value = vertical_proj_array[poz_max]

    while value > mean_value:
        i += 1
        value = vertical_proj_array[poz_max + i]

    upper_limit = poz_max + i

    # Extend interval by some values
    upper_limit = upper_limit * 1.1
    lower_limit = lower_limit * 0.9

    return (int(lower_limit), int(upper_limit))

eroded = []
def is_streamer_on_image(images):
    """Summary
    
    Args:
        images (TYPE): Description
    
    Returns:
        TYPE: Description
    """
    eroded_value = np.sum(cv2.erode(cv2.threshold(
        image, 2 * np.mean(image), 1, type=cv2.THRESH_BINARY)[1], np.ones((5, 5))))
    eroded.append(eroded_value)
    if eroded_value > 5:
        return True
    else:
        return False


def horizontal_projection(image):
    """Summary
    
    Args:
        image (TYPE): Description
    
    Returns:
        TYPE: Description
    
    Raises:
        IOError: Description
    """
    if type(image) != np.ndarray:
        raise TypeError("Image is not ndarray type")

    horizontal_proj_array = np.zeros(image.shape[1])
    horizontal_proj_array = np.mean(image, axis=0)
    return horizontal_proj_array

def remove_small_objects(labeled_image):
    if type(image) != np.ndarray:
        raise TypeError("Fuck it")

    centers = center_of_mass(labeled_image, labels = labeled_image, index=range(np.amax(labeled_image)))
    for i in range(1,len(centers)):
        centers[i] = (i, centers[i])

    print(centers)


    for i in range(1,len(centers)):
        for j in range(1,len(centers)):
            #print(centers[i][1][0])
            if abs(centers[i][1][0] - centers[j][1][0]) > 8 and abs(centers[i][1][1]-
                centers[j][1][1]) < 30:
                label_max = max(centers[i][0], centers[j][0])
                label_min = min(centers[i][0], centers[j][0])
                labeled_image[labeled_image == label_max] = label_min


    for i in range(np.amax(labeled_image)):
        if np.sum(labeled_image == i) < 200:
            labeled_image[labeled_image == i] = 0

    centers = center_of_mass(labeled_image, labels = labeled_image, index=range(np.amax(labeled_image)))
    for i in range(1,len(centers)):
        centers[i] = (i, centers[i])

    print(centers)


    return labeled_image

def experiments():
    """Summary
    """
    image = cv2.cvtColor(cv2.imread(
        "images_orig/0_1ms_9KV19.png"), cv2.COLOR_RGB2GRAY)
    image = image.astype(np.float64)
    image = cv2.normalize(image, dst=image, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX,
                          dtype=cv2.CV_64F)
    image_orig = np.copy(image)
    image[image < 0.0649] = 0
    image = cv2.blur(image, (15, 15))
    image[image > 1e-5] = 1
    fig, ax = pyplot.subplots(1, 2)
    bounds = detect_ROI(image_orig)
    #image = image[bounds[0]:bounds[1]]
    ax[0].imshow(image_orig, clim=(0, np.amax(cv2.blur(image, (5, 5)))))
    ax[1].plot(medfilt(vertical_projection(image_orig), 15)[-1::-1],np.arange(1024,0,-1), "-r", linewidth=3)
    ax[1].plot(np.ones(image_orig.shape[0]) *
               np.mean(vertical_projection(image_orig)), np.arange(1024,0,-1), "-b")
    pyplot.gca().invert_yaxis()

    ax[1].set_xlabel("mean intensity")
    ax[1].set_ylabel("row")
    pyplot.show()



def blur_and_threshold_image(image):
    """Summary
    
    Args:
        image (TYPE): Description
    
    Returns:
        TYPE: Description
    """
    image_blurred = cv2.GaussianBlur(image, (17,17),0)
    _,image_blurred = cv2.threshold(image_blurred, 3, 255, cv2.THRESH_BINARY)
    image_blurred = cv2.dilate(image_blurred, np.ones([7,3]))
    return image_blurred


def process_image(image):
    if is_streamer_on_image(image):
        return False
    image = image.astype(np.float64)
    image = cv2.normalize(image, dst = image, dtype = cv2.CV_64F)
    #FIXME: detect_roi returns positions, not image!
    bounds = detect_ROI(image)
    image = image[bounds[0]:bounds[1], :]
    image_blurred = blur_and_threshold_image(image)
    



    return remove_small_objects(image)

#FIXME: structuring element triangle form!
if __name__ == "__main__":
    means = []
    ifa = []
    for i in range(22, 24):
        image = cv2.cvtColor(cv2.imread(
            "images_orig/0_6ms_9KV" + str(i) + ".png"), cv2.COLOR_RGB2GRAY)
        image = image.astype(np.float64)
        if is_streamer_on_image(image):
            bounds = detect_ROI(image)
            image = image[bounds[0]:bounds[1], :]

            detect_streamers_watershed(image)

            #raise StarWarsException("End")


#TODO: implement two thresholds, one for centers, OTSU?, another one weaker, for merging objects.ins